import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by Sudhakar on 28/03/2016.
 */
public class Buyer extends BaseMain{
    WebDriver driver;
public verifyingnewbuyer enterbuyerdetail(){
    System.out.println("this page entering buyer details ");
    driver.findElement(By.xpath("html/body/div[2]/div[1]/ul/li[5]/a")).click();
    driver.findElement(By.xpath("html/body/div[2]/div[1]/ul/li[5]/ul/li[2]/a")).click();
    driver.findElement(By.xpath("//*[@id='search']/div[1]/div[2]/input")).click();
    driver.findElement(By.xpath("//*[@id='sname']")).sendKeys("");
    driver.findElement(By.xpath("//*[@id='email']")).sendKeys("");
    driver.findElement(By.xpath("//*[@id='saddress']")).sendKeys("");
    driver.findElement(By.xpath("//*[@id='cnumber']")).sendKeys("");
    driver.findElement(By.xpath("//*[@id='key']")).sendKeys("");
    driver.findElement(By.xpath("//*[@id='atitle']")).sendKeys("");
    driver.findElement(By.xpath("//*[@id='address']")).sendKeys("");
    driver.findElement(By.xpath("//*[@id='uname']")).sendKeys("");
    driver.findElement(By.xpath("//*[@id='password']")).sendKeys("");
    driver.findElement(By.xpath("//*[@id='retypepassword']")).sendKeys("");
    driver.findElement(By.xpath("//*[@id='newsupplier']/div/div[1]/div/div[1]/div[11]/p/div/div/span[3]")).click();
    driver.findElement(By.xpath("//*[@id='submit']")).click();
return new verifyingnewbuyer();
}
}
